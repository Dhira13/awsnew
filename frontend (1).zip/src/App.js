import './App.css';
import Frontpage from './components/Frontpage';

function App() {


  return (
    <div style={{overflow : "hidden"}}>
      <Frontpage />
    </div>
  );
}

export default App;
